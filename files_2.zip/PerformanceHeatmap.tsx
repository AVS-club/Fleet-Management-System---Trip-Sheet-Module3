import React, { useState, useMemo } from 'react';
import { 
  TrendingUp, TrendingDown, Minus, ChevronDown, ChevronUp,
  Truck, Users, Calendar, Filter, Download, Eye,
  AlertCircle, CheckCircle, XCircle
} from 'lucide-react';
import { format, subDays, startOfWeek, endOfWeek } from 'date-fns';
import { cn } from '@/lib/utils';

interface PerformanceMetric {
  id: string;
  name: string;
  current: number;
  previous: number;
  change: number;
  unit: string;
  status: 'good' | 'warning' | 'poor';
}

interface PerformanceEntity {
  id: string;
  name: string;
  type: 'vehicle' | 'driver';
  metrics: PerformanceMetric[];
  overallScore: number;
  rank: number;
}

interface PerformanceHeatmapProps {
  trips: any[];
  vehicles: any[];
  drivers: any[];
  maintenance: any[];
  dateRange?: { start: Date; end: Date };
}

export default function PerformanceHeatmap({
  trips = [],
  vehicles = [],
  drivers = [],
  maintenance = [],
  dateRange
}: PerformanceHeatmapProps) {
  
  const [viewMode, setViewMode] = useState<'vehicles' | 'drivers'>('vehicles');
  const [metricView, setMetricView] = useState<'trips' | 'mileage' | 'revenue' | 'utilization'>('revenue');
  const [timeframe, setTimeframe] = useState<'today' | 'week' | 'month'>('week');
  const [expandedRows, setExpandedRows] = useState<Set<string>>(new Set());
  
  // Calculate performance data
  const performanceData = useMemo(() => {
    const now = new Date();
    let currentStart: Date, currentEnd: Date, previousStart: Date, previousEnd: Date;
    
    // Define time ranges based on timeframe
    switch (timeframe) {
      case 'today':
        currentStart = startOfDay(now);
        currentEnd = endOfDay(now);
        previousStart = startOfDay(subDays(now, 1));
        previousEnd = endOfDay(subDays(now, 1));
        break;
      case 'week':
        currentStart = startOfWeek(now);
        currentEnd = endOfWeek(now);
        previousStart = startOfWeek(subDays(now, 7));
        previousEnd = endOfWeek(subDays(now, 7));
        break;
      case 'month':
        currentStart = new Date(now.getFullYear(), now.getMonth(), 1);
        currentEnd = new Date(now.getFullYear(), now.getMonth() + 1, 0);
        previousStart = new Date(now.getFullYear(), now.getMonth() - 1, 1);
        previousEnd = new Date(now.getFullYear(), now.getMonth(), 0);
        break;
    }
    
    // Use custom date range if provided
    if (dateRange) {
      currentStart = dateRange.start;
      currentEnd = dateRange.end;
      const duration = currentEnd.getTime() - currentStart.getTime();
      previousStart = new Date(currentStart.getTime() - duration);
      previousEnd = new Date(currentStart.getTime() - 1);
    }
    
    const entities: PerformanceEntity[] = [];
    
    if (viewMode === 'vehicles') {
      vehicles.forEach(vehicle => {
        const currentTrips = trips.filter(t => 
          t.vehicle_id === vehicle.id &&
          new Date(t.trip_start_date) >= currentStart &&
          new Date(t.trip_start_date) <= currentEnd
        );
        
        const previousTrips = trips.filter(t => 
          t.vehicle_id === vehicle.id &&
          new Date(t.trip_start_date) >= previousStart &&
          new Date(t.trip_start_date) <= previousEnd
        );
        
        // Calculate metrics
        const currentTripCount = currentTrips.length;
        const previousTripCount = previousTrips.length;
        const tripChange = previousTripCount > 0 
          ? ((currentTripCount - previousTripCount) / previousTripCount) * 100 
          : 0;
        
        const currentRevenue = currentTrips.reduce((sum, t) => sum + (t.net_profit || 0), 0);
        const previousRevenue = previousTrips.reduce((sum, t) => sum + (t.net_profit || 0), 0);
        const revenueChange = previousRevenue > 0 
          ? ((currentRevenue - previousRevenue) / previousRevenue) * 100 
          : 0;
        
        const currentMileage = currentTrips.length > 0
          ? currentTrips.reduce((sum, t) => sum + (t.calculated_kmpl || 0), 0) / currentTrips.length
          : 0;
        const previousMileage = previousTrips.length > 0
          ? previousTrips.reduce((sum, t) => sum + (t.calculated_kmpl || 0), 0) / previousTrips.length
          : 0;
        const mileageChange = previousMileage > 0 
          ? ((currentMileage - previousMileage) / previousMileage) * 100 
          : 0;
        
        // Calculate utilization (days with trips / total days)
        const currentDaysWithTrips = new Set(currentTrips.map(t => 
          format(new Date(t.trip_start_date), 'yyyy-MM-dd')
        )).size;
        const totalDays = Math.ceil((currentEnd.getTime() - currentStart.getTime()) / (1000 * 60 * 60 * 24));
        const utilization = (currentDaysWithTrips / totalDays) * 100;
        
        const metrics: PerformanceMetric[] = [
          {
            id: 'trips',
            name: 'Trips',
            current: currentTripCount,
            previous: previousTripCount,
            change: tripChange,
            unit: 'trips',
            status: tripChange >= 0 ? 'good' : tripChange > -20 ? 'warning' : 'poor'
          },
          {
            id: 'revenue',
            name: 'Revenue',
            current: currentRevenue,
            previous: previousRevenue,
            change: revenueChange,
            unit: '₹',
            status: revenueChange >= 0 ? 'good' : revenueChange > -20 ? 'warning' : 'poor'
          },
          {
            id: 'mileage',
            name: 'Mileage',
            current: currentMileage,
            previous: previousMileage,
            change: mileageChange,
            unit: 'km/L',
            status: mileageChange >= -5 ? 'good' : mileageChange > -15 ? 'warning' : 'poor'
          },
          {
            id: 'utilization',
            name: 'Utilization',
            current: utilization,
            previous: 0,
            change: 0,
            unit: '%',
            status: utilization >= 70 ? 'good' : utilization >= 40 ? 'warning' : 'poor'
          }
        ];
        
        // Calculate overall score
        const overallScore = 
          (metrics[0].status === 'good' ? 25 : metrics[0].status === 'warning' ? 10 : 0) +
          (metrics[1].status === 'good' ? 35 : metrics[1].status === 'warning' ? 15 : 0) +
          (metrics[2].status === 'good' ? 20 : metrics[2].status === 'warning' ? 10 : 0) +
          (metrics[3].status === 'good' ? 20 : metrics[3].status === 'warning' ? 10 : 0);
        
        entities.push({
          id: vehicle.id,
          name: vehicle.registration_number,
          type: 'vehicle',
          metrics,
          overallScore,
          rank: 0
        });
      });
    } else {
      // Similar logic for drivers
      drivers.forEach(driver => {
        const currentTrips = trips.filter(t => 
          t.driver_id === driver.id &&
          new Date(t.trip_start_date) >= currentStart &&
          new Date(t.trip_start_date) <= currentEnd
        );
        
        const previousTrips = trips.filter(t => 
          t.driver_id === driver.id &&
          new Date(t.trip_start_date) >= previousStart &&
          new Date(t.trip_start_date) <= previousEnd
        );
        
        // Calculate driver metrics (similar to vehicle metrics)
        const currentTripCount = currentTrips.length;
        const previousTripCount = previousTrips.length;
        const tripChange = previousTripCount > 0 
          ? ((currentTripCount - previousTripCount) / previousTripCount) * 100 
          : 0;
        
        const currentRevenue = currentTrips.reduce((sum, t) => sum + (t.net_profit || 0), 0);
        const previousRevenue = previousTrips.reduce((sum, t) => sum + (t.net_profit || 0), 0);
        const revenueChange = previousRevenue > 0 
          ? ((currentRevenue - previousRevenue) / previousRevenue) * 100 
          : 0;
        
        const currentMileage = currentTrips.length > 0
          ? currentTrips.reduce((sum, t) => sum + (t.calculated_kmpl || 0), 0) / currentTrips.length
          : 0;
        const previousMileage = previousTrips.length > 0
          ? previousTrips.reduce((sum, t) => sum + (t.calculated_kmpl || 0), 0) / previousTrips.length
          : 0;
        const mileageChange = previousMileage > 0 
          ? ((currentMileage - previousMileage) / previousMileage) * 100 
          : 0;
        
        const metrics: PerformanceMetric[] = [
          {
            id: 'trips',
            name: 'Trips',
            current: currentTripCount,
            previous: previousTripCount,
            change: tripChange,
            unit: 'trips',
            status: tripChange >= 0 ? 'good' : tripChange > -20 ? 'warning' : 'poor'
          },
          {
            id: 'revenue',
            name: 'Revenue',
            current: currentRevenue,
            previous: previousRevenue,
            change: revenueChange,
            unit: '₹',
            status: revenueChange >= 0 ? 'good' : revenueChange > -20 ? 'warning' : 'poor'
          },
          {
            id: 'mileage',
            name: 'Avg Mileage',
            current: currentMileage,
            previous: previousMileage,
            change: mileageChange,
            unit: 'km/L',
            status: mileageChange >= -5 ? 'good' : mileageChange > -15 ? 'warning' : 'poor'
          },
          {
            id: 'efficiency',
            name: 'Efficiency',
            current: currentRevenue / (currentTripCount || 1),
            previous: previousRevenue / (previousTripCount || 1),
            change: 0,
            unit: '₹/trip',
            status: currentRevenue / (currentTripCount || 1) >= 1000 ? 'good' : 'warning'
          }
        ];
        
        const overallScore = 
          (metrics[0].status === 'good' ? 25 : metrics[0].status === 'warning' ? 10 : 0) +
          (metrics[1].status === 'good' ? 35 : metrics[1].status === 'warning' ? 15 : 0) +
          (metrics[2].status === 'good' ? 20 : metrics[2].status === 'warning' ? 10 : 0) +
          (metrics[3].status === 'good' ? 20 : metrics[3].status === 'warning' ? 10 : 0);
        
        entities.push({
          id: driver.id,
          name: driver.name,
          type: 'driver',
          metrics,
          overallScore,
          rank: 0
        });
      });
    }
    
    // Sort by overall score and assign ranks
    entities.sort((a, b) => b.overallScore - a.overallScore);
    entities.forEach((entity, index) => {
      entity.rank = index + 1;
    });
    
    return entities;
  }, [trips, vehicles, drivers, viewMode, timeframe, dateRange]);
  
  const toggleRowExpansion = (id: string) => {
    const newExpanded = new Set(expandedRows);
    if (newExpanded.has(id)) {
      newExpanded.delete(id);
    } else {
      newExpanded.add(id);
    }
    setExpandedRows(newExpanded);
  };
  
  const getHeatmapColor = (value: number, metric: string) => {
    if (metric === 'revenue' || metric === 'trips') {
      if (value >= 10) return 'bg-green-500 text-white';
      if (value >= 0) return 'bg-green-300 text-green-900';
      if (value >= -10) return 'bg-yellow-300 text-yellow-900';
      if (value >= -20) return 'bg-orange-400 text-white';
      return 'bg-red-500 text-white';
    } else if (metric === 'mileage') {
      if (value >= 0) return 'bg-green-500 text-white';
      if (value >= -5) return 'bg-green-300 text-green-900';
      if (value >= -10) return 'bg-yellow-300 text-yellow-900';
      if (value >= -15) return 'bg-orange-400 text-white';
      return 'bg-red-500 text-white';
    } else {
      // Utilization
      if (value >= 70) return 'bg-green-500 text-white';
      if (value >= 50) return 'bg-green-300 text-green-900';
      if (value >= 30) return 'bg-yellow-300 text-yellow-900';
      if (value >= 20) return 'bg-orange-400 text-white';
      return 'bg-red-500 text-white';
    }
  };
  
  const getRankBadge = (rank: number) => {
    if (rank === 1) return '🥇';
    if (rank === 2) return '🥈';
    if (rank === 3) return '🥉';
    return `#${rank}`;
  };
  
  // Import statements for missing functions
  const startOfDay = (date: Date) => {
    const d = new Date(date);
    d.setHours(0, 0, 0, 0);
    return d;
  };
  
  const endOfDay = (date: Date) => {
    const d = new Date(date);
    d.setHours(23, 59, 59, 999);
    return d;
  };
  
  return (
    <div className="bg-white dark:bg-gray-900 rounded-lg shadow-sm">
      {/* Header */}
      <div className="p-6 border-b border-gray-200 dark:border-gray-700">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
          <div>
            <h2 className="text-lg font-semibold text-gray-900 dark:text-gray-100">
              Performance Heatmap
            </h2>
            <p className="text-sm text-gray-500 dark:text-gray-400 mt-1">
              Comparative performance analysis across your fleet
            </p>
          </div>
          
          {/* Controls */}
          <div className="flex flex-wrap gap-2">
            {/* View Mode Toggle */}
            <div className="flex bg-gray-100 dark:bg-gray-800 rounded-lg p-1">
              <button
                onClick={() => setViewMode('vehicles')}
                className={cn(
                  "px-3 py-1.5 rounded-md text-sm font-medium transition-all flex items-center gap-1",
                  viewMode === 'vehicles'
                    ? "bg-white dark:bg-gray-700 text-gray-900 dark:text-gray-100 shadow-sm"
                    : "text-gray-600 dark:text-gray-400"
                )}
              >
                <Truck className="h-3 w-3" />
                Vehicles
              </button>
              <button
                onClick={() => setViewMode('drivers')}
                className={cn(
                  "px-3 py-1.5 rounded-md text-sm font-medium transition-all flex items-center gap-1",
                  viewMode === 'drivers'
                    ? "bg-white dark:bg-gray-700 text-gray-900 dark:text-gray-100 shadow-sm"
                    : "text-gray-600 dark:text-gray-400"
                )}
              >
                <Users className="h-3 w-3" />
                Drivers
              </button>
            </div>
            
            {/* Timeframe Selector */}
            <select
              value={timeframe}
              onChange={(e) => setTimeframe(e.target.value as any)}
              className="px-3 py-1.5 bg-white dark:bg-gray-800 border border-gray-300 dark:border-gray-600 rounded-lg text-sm text-gray-900 dark:text-gray-100"
            >
              <option value="today">Today vs Yesterday</option>
              <option value="week">This Week vs Last</option>
              <option value="month">This Month vs Last</option>
            </select>
            
            {/* Export Button */}
            <button className="p-1.5 text-gray-600 dark:text-gray-400 hover:bg-gray-100 dark:hover:bg-gray-800 rounded-lg transition-colors">
              <Download className="h-4 w-4" />
            </button>
          </div>
        </div>
        
        {/* Metric Selector */}
        <div className="flex gap-2 mt-4 overflow-x-auto">
          {['revenue', 'trips', 'mileage', 'utilization'].map(metric => (
            <button
              key={metric}
              onClick={() => setMetricView(metric as any)}
              className={cn(
                "px-3 py-1.5 rounded-lg text-sm font-medium capitalize whitespace-nowrap transition-all",
                metricView === metric
                  ? "bg-primary-100 dark:bg-primary-900/30 text-primary-700 dark:text-primary-300"
                  : "bg-gray-100 dark:bg-gray-800 text-gray-600 dark:text-gray-400 hover:bg-gray-200 dark:hover:bg-gray-700"
              )}
            >
              {metric === 'utilization' && viewMode === 'drivers' ? 'Efficiency' : metric}
            </button>
          ))}
        </div>
      </div>
      
      {/* Heatmap Grid */}
      <div className="overflow-x-auto">
        <table className="w-full">
          <thead className="bg-gray-50 dark:bg-gray-800">
            <tr>
              <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                Rank
              </th>
              <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                {viewMode === 'vehicles' ? 'Vehicle' : 'Driver'}
              </th>
              <th className="px-4 py-3 text-center text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                Score
              </th>
              <th className="px-4 py-3 text-center text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                Current
              </th>
              <th className="px-4 py-3 text-center text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                Previous
              </th>
              <th className="px-4 py-3 text-center text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                Change
              </th>
              <th className="px-4 py-3 text-center text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                Status
              </th>
            </tr>
          </thead>
          <tbody className="divide-y divide-gray-200 dark:divide-gray-700">
            {performanceData.map((entity) => {
              const metric = entity.metrics.find(m => m.id === metricView);
              const isExpanded = expandedRows.has(entity.id);
              
              return (
                <React.Fragment key={entity.id}>
                  <tr 
                    className="hover:bg-gray-50 dark:hover:bg-gray-800 cursor-pointer"
                    onClick={() => toggleRowExpansion(entity.id)}
                  >
                    <td className="px-4 py-3 text-sm font-medium text-gray-900 dark:text-gray-100">
                      {getRankBadge(entity.rank)}
                    </td>
                    <td className="px-4 py-3">
                      <div className="flex items-center gap-2">
                        <span className="text-sm font-medium text-gray-900 dark:text-gray-100">
                          {entity.name}
                        </span>
                        {entity.rank <= 3 && (
                          <span className="px-1.5 py-0.5 bg-yellow-100 dark:bg-yellow-900/30 text-yellow-700 dark:text-yellow-300 text-xs rounded-full">
                            Top Performer
                          </span>
                        )}
                      </div>
                    </td>
                    <td className="px-4 py-3 text-center">
                      <div className={cn(
                        "inline-flex items-center justify-center w-12 h-12 rounded-full text-sm font-bold",
                        entity.overallScore >= 70 ? "bg-green-100 dark:bg-green-900/30 text-green-700 dark:text-green-300" :
                        entity.overallScore >= 40 ? "bg-yellow-100 dark:bg-yellow-900/30 text-yellow-700 dark:text-yellow-300" :
                        "bg-red-100 dark:bg-red-900/30 text-red-700 dark:text-red-300"
                      )}>
                        {entity.overallScore}
                      </div>
                    </td>
                    <td className="px-4 py-3 text-center">
                      <span className="text-sm font-medium text-gray-900 dark:text-gray-100">
                        {metric?.unit === '₹' 
                          ? `₹${metric.current.toLocaleString('en-IN')}` 
                          : metric?.unit === 'km/L'
                          ? metric.current.toFixed(1)
                          : metric?.unit === '%'
                          ? `${metric.current.toFixed(0)}%`
                          : metric?.current}
                      </span>
                    </td>
                    <td className="px-4 py-3 text-center">
                      <span className="text-sm text-gray-600 dark:text-gray-400">
                        {metric?.unit === '₹' 
                          ? `₹${metric.previous.toLocaleString('en-IN')}` 
                          : metric?.unit === 'km/L'
                          ? metric.previous.toFixed(1)
                          : metric?.unit === '%'
                          ? `${metric.previous.toFixed(0)}%`
                          : metric?.previous}
                      </span>
                    </td>
                    <td className="px-4 py-3 text-center">
                      <div className={cn(
                        "inline-flex items-center gap-1 px-2 py-1 rounded-full text-xs font-medium",
                        getHeatmapColor(metric?.change || 0, metricView)
                      )}>
                        {metric?.change !== undefined && metric.change !== 0 && (
                          <>
                            {metric.change > 0 ? 
                              <TrendingUp className="h-3 w-3" /> : 
                              <TrendingDown className="h-3 w-3" />
                            }
                            {Math.abs(metric.change).toFixed(0)}%
                          </>
                        )}
                        {metric?.change === 0 && <Minus className="h-3 w-3" />}
                      </div>
                    </td>
                    <td className="px-4 py-3 text-center">
                      {metric?.status === 'good' && <CheckCircle className="h-5 w-5 text-green-500 mx-auto" />}
                      {metric?.status === 'warning' && <AlertCircle className="h-5 w-5 text-yellow-500 mx-auto" />}
                      {metric?.status === 'poor' && <XCircle className="h-5 w-5 text-red-500 mx-auto" />}
                    </td>
                  </tr>
                  
                  {/* Expanded Details */}
                  {isExpanded && (
                    <tr>
                      <td colSpan={7} className="px-4 py-3 bg-gray-50 dark:bg-gray-800/50">
                        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                          {entity.metrics.map(m => (
                            <div key={m.id} className="text-center">
                              <div className="text-xs text-gray-500 dark:text-gray-400 uppercase">
                                {m.name}
                              </div>
                              <div className="text-lg font-semibold text-gray-900 dark:text-gray-100 mt-1">
                                {m.unit === '₹' 
                                  ? `₹${m.current.toLocaleString('en-IN')}` 
                                  : m.unit === 'km/L'
                                  ? m.current.toFixed(1)
                                  : m.unit === '%'
                                  ? `${m.current.toFixed(0)}%`
                                  : m.current}
                                <span className="text-xs text-gray-500 dark:text-gray-400 ml-1">
                                  {m.unit !== '₹' && m.unit !== '%' && m.unit}
                                </span>
                              </div>
                              <div className={cn(
                                "text-xs font-medium mt-1",
                                m.change > 0 ? "text-green-600" : m.change < 0 ? "text-red-600" : "text-gray-500"
                              )}>
                                {m.change > 0 && '+'}
                                {m.change.toFixed(0)}%
                              </div>
                            </div>
                          ))}
                        </div>
                      </td>
                    </tr>
                  )}
                </React.Fragment>
              );
            })}
          </tbody>
        </table>
      </div>
      
      {/* Legend */}
      <div className="p-4 border-t border-gray-200 dark:border-gray-700">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-4 text-xs">
            <span className="text-gray-500 dark:text-gray-400">Performance Scale:</span>
            <div className="flex items-center gap-1">
              <div className="w-4 h-4 bg-green-500 rounded"></div>
              <span className="text-gray-600 dark:text-gray-400">Excellent</span>
            </div>
            <div className="flex items-center gap-1">
              <div className="w-4 h-4 bg-yellow-300 rounded"></div>
              <span className="text-gray-600 dark:text-gray-400">Average</span>
            </div>
            <div className="flex items-center gap-1">
              <div className="w-4 h-4 bg-red-500 rounded"></div>
              <span className="text-gray-600 dark:text-gray-400">Poor</span>
            </div>
          </div>
          
          <button className="text-sm text-primary-600 dark:text-primary-400 hover:text-primary-700 dark:hover:text-primary-300 font-medium">
            Export Report
          </button>
        </div>
      </div>
    </div>
  );
}
