import React, { useMemo } from 'react';
import { Shield, AlertCircle, CheckCircle, TrendingDown } from 'lucide-react';
import { cn } from '@/lib/utils';

interface HealthMetric {
  category: string;
  score: number;
  issues: string[];
  weight: number;
}

interface FleetHealthScoreProps {
  trips: any[];
  vehicles: any[];
  drivers: any[];
  documents: any[];
  maintenance: any[];
}

export default function FleetHealthScore({
  trips = [],
  vehicles = [],
  drivers = [],
  documents = [],
  maintenance = []
}: FleetHealthScoreProps) {
  
  const healthMetrics = useMemo(() => {
    const metrics: HealthMetric[] = [];
    
    // 1. Vehicle Utilization Score (25% weight)
    const activeVehicles = vehicles.filter(v => v.status === 'active').length;
    const idleVehicles = vehicles.filter(v => {
      const lastTrip = trips.find(t => t.vehicle_id === v.id);
      if (!lastTrip) return true;
      const daysSinceLastTrip = Math.floor((Date.now() - new Date(lastTrip.trip_end_date).getTime()) / (1000 * 60 * 60 * 24));
      return daysSinceLastTrip > 2;
    }).length;
    
    const utilizationScore = vehicles.length > 0 
      ? Math.round((1 - idleVehicles / vehicles.length) * 100)
      : 100;
    
    metrics.push({
      category: 'Vehicle Utilization',
      score: utilizationScore,
      issues: idleVehicles > 0 ? [`${idleVehicles} vehicles idle for >2 days`] : [],
      weight: 0.25
    });
    
    // 2. Document Compliance Score (20% weight)
    const today = new Date();
    const expiringDocs = documents.filter(doc => {
      const expiryDate = new Date(doc.expiry_date);
      const daysToExpiry = Math.floor((expiryDate.getTime() - today.getTime()) / (1000 * 60 * 60 * 24));
      return daysToExpiry <= 7 && daysToExpiry >= 0;
    });
    
    const expiredDocs = documents.filter(doc => {
      const expiryDate = new Date(doc.expiry_date);
      return expiryDate < today;
    });
    
    const docScore = documents.length > 0
      ? Math.round((1 - (expiredDocs.length + expiringDocs.length * 0.5) / documents.length) * 100)
      : 100;
    
    const docIssues = [];
    if (expiredDocs.length > 0) docIssues.push(`${expiredDocs.length} documents expired`);
    if (expiringDocs.length > 0) docIssues.push(`${expiringDocs.length} expiring in 7 days`);
    
    metrics.push({
      category: 'Document Compliance',
      score: Math.max(0, docScore),
      issues: docIssues,
      weight: 0.20
    });
    
    // 3. Maintenance Health Score (20% weight)
    const overdueMaintenances = maintenance.filter(m => 
      m.status === 'scheduled' && new Date(m.scheduled_date) < today
    ).length;
    
    const upcomingCritical = maintenance.filter(m => {
      const daysToMaintenance = Math.floor((new Date(m.scheduled_date).getTime() - today.getTime()) / (1000 * 60 * 60 * 24));
      return daysToMaintenance <= 3 && daysToMaintenance >= 0 && m.priority === 'high';
    }).length;
    
    const maintenanceScore = maintenance.length > 0
      ? Math.round((1 - (overdueMaintenances + upcomingCritical * 0.5) / maintenance.length) * 100)
      : 100;
    
    const maintenanceIssues = [];
    if (overdueMaintenances > 0) maintenanceIssues.push(`${overdueMaintenances} overdue services`);
    if (upcomingCritical > 0) maintenanceIssues.push(`${upcomingCritical} critical maintenances due`);
    
    metrics.push({
      category: 'Maintenance',
      score: Math.max(0, maintenanceScore),
      issues: maintenanceIssues,
      weight: 0.20
    });
    
    // 4. Performance Score (20% weight) - Fuel efficiency & trip profitability
    const recentTrips = trips.slice(-20);
    const avgMileage = recentTrips.reduce((sum, trip) => sum + (trip.calculated_kmpl || 0), 0) / (recentTrips.length || 1);
    const expectedMileage = 8; // Expected minimum mileage
    
    const lowProfitTrips = recentTrips.filter(t => {
      const profitMargin = t.net_profit / (t.total_cost || 1);
      return profitMargin < 0.15; // Less than 15% profit margin
    }).length;
    
    const performanceScore = Math.round(
      ((avgMileage / expectedMileage) * 0.5 + (1 - lowProfitTrips / (recentTrips.length || 1)) * 0.5) * 100
    );
    
    const performanceIssues = [];
    if (avgMileage < expectedMileage) performanceIssues.push(`Low avg mileage: ${avgMileage.toFixed(1)} km/L`);
    if (lowProfitTrips > 0) performanceIssues.push(`${lowProfitTrips} low-profit trips`);
    
    metrics.push({
      category: 'Performance',
      score: Math.min(100, Math.max(0, performanceScore)),
      issues: performanceIssues,
      weight: 0.20
    });
    
    // 5. Driver Performance Score (15% weight)
    const activeDrivers = drivers.filter(d => d.status === 'active').length;
    const driverUtilization = drivers.length > 0 ? (activeDrivers / drivers.length) : 1;
    
    const driverScore = Math.round(driverUtilization * 100);
    
    metrics.push({
      category: 'Driver Management',
      score: driverScore,
      issues: drivers.length - activeDrivers > 0 
        ? [`${drivers.length - activeDrivers} inactive drivers`] 
        : [],
      weight: 0.15
    });
    
    return metrics;
  }, [trips, vehicles, drivers, documents, maintenance]);
  
  const overallScore = useMemo(() => {
    const weightedScore = healthMetrics.reduce((sum, metric) => 
      sum + (metric.score * metric.weight), 0
    );
    return Math.round(weightedScore);
  }, [healthMetrics]);
  
  const scoreColor = useMemo(() => {
    if (overallScore >= 80) return 'text-green-600 bg-green-50 border-green-200';
    if (overallScore >= 60) return 'text-yellow-600 bg-yellow-50 border-yellow-200';
    return 'text-red-600 bg-red-50 border-red-200';
  }, [overallScore]);
  
  const scoreIcon = useMemo(() => {
    if (overallScore >= 80) return <CheckCircle className="h-8 w-8 text-green-600" />;
    if (overallScore >= 60) return <AlertCircle className="h-8 w-8 text-yellow-600" />;
    return <TrendingDown className="h-8 w-8 text-red-600" />;
  }, [overallScore]);
  
  const allIssues = healthMetrics.flatMap(m => m.issues);
  
  return (
    <div className="bg-white dark:bg-gray-900 rounded-lg shadow-sm p-6 mb-6">
      {/* Main Score Display */}
      <div className="flex items-center justify-between mb-6">
        <div>
          <h2 className="text-lg font-semibold text-gray-900 dark:text-gray-100 mb-1">
            Fleet Health Score
          </h2>
          <p className="text-sm text-gray-500 dark:text-gray-400">
            Real-time fleet performance analysis
          </p>
        </div>
        
        <div className={cn(
          "flex items-center gap-3 px-6 py-4 rounded-xl border-2",
          scoreColor
        )}>
          {scoreIcon}
          <div>
            <div className="text-3xl font-bold">{overallScore}</div>
            <div className="text-xs font-medium uppercase">
              {overallScore >= 80 ? 'Excellent' : overallScore >= 60 ? 'Attention' : 'Critical'}
            </div>
          </div>
        </div>
      </div>
      
      {/* Metric Breakdown */}
      <div className="grid grid-cols-1 md:grid-cols-5 gap-3 mb-4">
        {healthMetrics.map((metric) => (
          <div key={metric.category} className="relative">
            <div className="text-xs font-medium text-gray-500 dark:text-gray-400 mb-1">
              {metric.category}
            </div>
            <div className="flex items-center gap-2">
              <div className="flex-1 bg-gray-200 dark:bg-gray-700 rounded-full h-2 overflow-hidden">
                <div 
                  className={cn(
                    "h-full transition-all duration-500",
                    metric.score >= 80 ? "bg-green-500" :
                    metric.score >= 60 ? "bg-yellow-500" : "bg-red-500"
                  )}
                  style={{ width: `${metric.score}%` }}
                />
              </div>
              <span className="text-sm font-medium text-gray-700 dark:text-gray-300 min-w-[35px]">
                {metric.score}%
              </span>
            </div>
            {metric.issues.length > 0 && (
              <div className="absolute -top-1 -right-1">
                <span className="flex h-2 w-2">
                  <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-red-400 opacity-75"></span>
                  <span className="relative inline-flex rounded-full h-2 w-2 bg-red-500"></span>
                </span>
              </div>
            )}
          </div>
        ))}
      </div>
      
      {/* Critical Issues Alert */}
      {allIssues.length > 0 && (
        <div className="mt-4 p-3 bg-red-50 dark:bg-red-900/20 border border-red-200 dark:border-red-800 rounded-lg">
          <div className="flex items-start gap-2">
            <AlertCircle className="h-5 w-5 text-red-600 dark:text-red-400 flex-shrink-0 mt-0.5" />
            <div>
              <h4 className="text-sm font-medium text-red-900 dark:text-red-100 mb-1">
                Attention Required ({allIssues.length} issues)
              </h4>
              <ul className="text-xs text-red-700 dark:text-red-300 space-y-1">
                {allIssues.slice(0, 3).map((issue, idx) => (
                  <li key={idx} className="flex items-center gap-1">
                    <span className="w-1 h-1 bg-red-500 rounded-full"></span>
                    {issue}
                  </li>
                ))}
                {allIssues.length > 3 && (
                  <li className="text-red-600 dark:text-red-400 font-medium">
                    +{allIssues.length - 3} more issues
                  </li>
                )}
              </ul>
            </div>
          </div>
        </div>
      )}
      
      {/* Quick Actions */}
      <div className="mt-4 flex flex-wrap gap-2">
        <button className="px-3 py-1.5 text-xs font-medium text-primary-600 dark:text-primary-400 bg-primary-50 dark:bg-primary-900/30 rounded-lg hover:bg-primary-100 dark:hover:bg-primary-900/50 transition-colors">
          View Details
        </button>
        <button className="px-3 py-1.5 text-xs font-medium text-gray-600 dark:text-gray-400 bg-gray-100 dark:bg-gray-800 rounded-lg hover:bg-gray-200 dark:hover:bg-gray-700 transition-colors">
          Generate Report
        </button>
        {overallScore < 80 && (
          <button className="px-3 py-1.5 text-xs font-medium text-red-600 dark:text-red-400 bg-red-50 dark:bg-red-900/30 rounded-lg hover:bg-red-100 dark:hover:bg-red-900/50 transition-colors">
            Fix Issues
          </button>
        )}
      </div>
    </div>
  );
}
