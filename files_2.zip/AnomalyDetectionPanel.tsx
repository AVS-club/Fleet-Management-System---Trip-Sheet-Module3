import React, { useMemo } from 'react';
import { 
  TrendingDown, TrendingUp, AlertTriangle, Activity, 
  Fuel, Clock, DollarSign, MapPin, Users, Shield,
  ChevronRight, Eye, Zap
} from 'lucide-react';
import { differenceInDays, format, subDays } from 'date-fns';
import { cn } from '@/lib/utils';

interface Anomaly {
  id: string;
  type: 'critical' | 'warning' | 'info' | 'success';
  category: 'vehicle' | 'driver' | 'trip' | 'maintenance' | 'document' | 'expense';
  title: string;
  description: string;
  metric?: {
    current: number | string;
    previous: number | string;
    change: number;
    unit: string;
  };
  action?: {
    label: string;
    onClick: () => void;
  };
  timestamp: Date;
  icon: React.ReactNode;
}

interface AnomalyDetectionPanelProps {
  trips: any[];
  vehicles: any[];
  drivers: any[];
  documents: any[];
  maintenance: any[];
  expenses: any[];
}

export default function AnomalyDetectionPanel({
  trips = [],
  vehicles = [],
  drivers = [],
  documents = [],
  maintenance = [],
  expenses = []
}: AnomalyDetectionPanelProps) {
  
  const anomalies = useMemo(() => {
    const detectedAnomalies: Anomaly[] = [];
    const today = new Date();
    const yesterday = subDays(today, 1);
    const lastWeek = subDays(today, 7);
    
    // 1. Vehicle Performance Anomalies
    vehicles.forEach(vehicle => {
      const vehicleTrips = trips.filter(t => t.vehicle_id === vehicle.id);
      const recentTrips = vehicleTrips.filter(t => 
        new Date(t.trip_start_date) >= lastWeek
      );
      const olderTrips = vehicleTrips.filter(t => 
        new Date(t.trip_start_date) < lastWeek && 
        new Date(t.trip_start_date) >= subDays(lastWeek, 7)
      );
      
      if (recentTrips.length > 0 && olderTrips.length > 0) {
        const recentAvgMileage = recentTrips.reduce((sum, t) => sum + (t.calculated_kmpl || 0), 0) / recentTrips.length;
        const olderAvgMileage = olderTrips.reduce((sum, t) => sum + (t.calculated_kmpl || 0), 0) / olderTrips.length;
        
        const mileageChange = ((recentAvgMileage - olderAvgMileage) / olderAvgMileage) * 100;
        
        if (mileageChange < -15) {
          detectedAnomalies.push({
            id: `vehicle-mileage-${vehicle.id}`,
            type: 'warning',
            category: 'vehicle',
            title: `${vehicle.registration_number} - Mileage Drop`,
            description: `Fuel efficiency decreased by ${Math.abs(mileageChange).toFixed(1)}% this week`,
            metric: {
              current: recentAvgMileage.toFixed(1),
              previous: olderAvgMileage.toFixed(1),
              change: mileageChange,
              unit: 'km/L'
            },
            timestamp: new Date(),
            icon: <Fuel className="h-4 w-4" />,
            action: {
              label: 'Schedule Service',
              onClick: () => console.log('Schedule service for', vehicle.id)
            }
          });
        }
      }
      
      // Check for idle vehicles
      const lastTrip = vehicleTrips[vehicleTrips.length - 1];
      if (lastTrip) {
        const daysSinceLastTrip = differenceInDays(today, new Date(lastTrip.trip_end_date));
        if (daysSinceLastTrip > 3) {
          detectedAnomalies.push({
            id: `vehicle-idle-${vehicle.id}`,
            type: 'info',
            category: 'vehicle',
            title: `${vehicle.registration_number} Idle`,
            description: `No trips for ${daysSinceLastTrip} days`,
            timestamp: new Date(),
            icon: <Clock className="h-4 w-4" />,
            action: {
              label: 'Assign Trip',
              onClick: () => console.log('Assign trip to', vehicle.id)
            }
          });
        }
      }
    });
    
    // 2. Driver Performance Anomalies
    drivers.forEach(driver => {
      const driverTrips = trips.filter(t => t.driver_id === driver.id);
      const recentTrips = driverTrips.filter(t => 
        new Date(t.trip_start_date) >= lastWeek
      );
      
      if (recentTrips.length > 0) {
        const avgProfitMargin = recentTrips.reduce((sum, t) => {
          const margin = t.net_profit / (t.total_cost || 1);
          return sum + margin;
        }, 0) / recentTrips.length;
        
        if (avgProfitMargin < 0.1) {
          detectedAnomalies.push({
            id: `driver-profit-${driver.id}`,
            type: 'warning',
            category: 'driver',
            title: `${driver.name} - Low Profit Margins`,
            description: `Average profit margin only ${(avgProfitMargin * 100).toFixed(1)}% this week`,
            metric: {
              current: `${(avgProfitMargin * 100).toFixed(1)}%`,
              previous: '15%',
              change: -((0.15 - avgProfitMargin) / 0.15 * 100),
              unit: ''
            },
            timestamp: new Date(),
            icon: <DollarSign className="h-4 w-4" />,
            action: {
              label: 'Review Routes',
              onClick: () => console.log('Review routes for', driver.id)
            }
          });
        }
        
        // Check for sudden trip volume change
        const olderTrips = driverTrips.filter(t => 
          new Date(t.trip_start_date) < lastWeek && 
          new Date(t.trip_start_date) >= subDays(lastWeek, 7)
        );
        
        if (olderTrips.length > 0) {
          const tripChange = ((recentTrips.length - olderTrips.length) / olderTrips.length) * 100;
          
          if (tripChange < -30) {
            detectedAnomalies.push({
              id: `driver-trips-${driver.id}`,
              type: 'info',
              category: 'driver',
              title: `${driver.name} - Reduced Activity`,
              description: `${Math.abs(tripChange).toFixed(0)}% fewer trips this week`,
              metric: {
                current: recentTrips.length,
                previous: olderTrips.length,
                change: tripChange,
                unit: 'trips'
              },
              timestamp: new Date(),
              icon: <Users className="h-4 w-4" />
            });
          }
        }
      }
    });
    
    // 3. Document Expiry Anomalies
    documents.forEach(doc => {
      const expiryDate = new Date(doc.expiry_date);
      const daysToExpiry = differenceInDays(expiryDate, today);
      
      if (daysToExpiry <= 7 && daysToExpiry >= 0) {
        detectedAnomalies.push({
          id: `doc-expiry-${doc.id}`,
          type: daysToExpiry <= 3 ? 'critical' : 'warning',
          category: 'document',
          title: `${doc.document_type} Expiring`,
          description: `${doc.vehicle_registration || 'Document'} expires in ${daysToExpiry} days`,
          timestamp: new Date(),
          icon: <Shield className="h-4 w-4" />,
          action: {
            label: 'Renew Now',
            onClick: () => console.log('Renew document', doc.id)
          }
        });
      } else if (daysToExpiry < 0) {
        detectedAnomalies.push({
          id: `doc-expired-${doc.id}`,
          type: 'critical',
          category: 'document',
          title: `${doc.document_type} EXPIRED`,
          description: `${doc.vehicle_registration || 'Document'} expired ${Math.abs(daysToExpiry)} days ago`,
          timestamp: new Date(),
          icon: <AlertTriangle className="h-4 w-4" />,
          action: {
            label: 'Urgent Renewal',
            onClick: () => console.log('Urgent renewal', doc.id)
          }
        });
      }
    });
    
    // 4. Maintenance Anomalies
    maintenance.forEach(task => {
      const scheduledDate = new Date(task.scheduled_date);
      const daysUntilDue = differenceInDays(scheduledDate, today);
      
      if (task.status === 'scheduled') {
        if (daysUntilDue < 0) {
          detectedAnomalies.push({
            id: `maintenance-overdue-${task.id}`,
            type: 'critical',
            category: 'maintenance',
            title: `Overdue Maintenance`,
            description: `${task.vehicle_registration} - ${task.maintenance_type} overdue by ${Math.abs(daysUntilDue)} days`,
            timestamp: new Date(),
            icon: <AlertTriangle className="h-4 w-4" />,
            action: {
              label: 'Schedule Now',
              onClick: () => console.log('Schedule maintenance', task.id)
            }
          });
        } else if (daysUntilDue <= 3) {
          detectedAnomalies.push({
            id: `maintenance-upcoming-${task.id}`,
            type: 'warning',
            category: 'maintenance',
            title: `Upcoming Maintenance`,
            description: `${task.vehicle_registration} - ${task.maintenance_type} due in ${daysUntilDue} days`,
            timestamp: new Date(),
            icon: <Activity className="h-4 w-4" />,
            action: {
              label: 'View Details',
              onClick: () => console.log('View maintenance', task.id)
            }
          });
        }
      }
    });
    
    // 5. Expense Anomalies
    const recentExpenses = expenses.filter(e => 
      new Date(e.expense_date) >= lastWeek
    );
    const olderExpenses = expenses.filter(e => 
      new Date(e.expense_date) < lastWeek && 
      new Date(e.expense_date) >= subDays(lastWeek, 7)
    );
    
    if (recentExpenses.length > 0 && olderExpenses.length > 0) {
      const recentTotal = recentExpenses.reduce((sum, e) => sum + e.amount, 0);
      const olderTotal = olderExpenses.reduce((sum, e) => sum + e.amount, 0);
      const expenseChange = ((recentTotal - olderTotal) / olderTotal) * 100;
      
      if (expenseChange > 30) {
        detectedAnomalies.push({
          id: 'expense-spike',
          type: 'warning',
          category: 'expense',
          title: 'Expense Spike Detected',
          description: `Expenses increased by ${expenseChange.toFixed(1)}% this week`,
          metric: {
            current: `₹${recentTotal.toLocaleString('en-IN')}`,
            previous: `₹${olderTotal.toLocaleString('en-IN')}`,
            change: expenseChange,
            unit: ''
          },
          timestamp: new Date(),
          icon: <TrendingUp className="h-4 w-4" />,
          action: {
            label: 'Analyze Expenses',
            onClick: () => console.log('Analyze expenses')
          }
        });
      }
    }
    
    // 6. Positive Anomalies (Good news!)
    const todayTrips = trips.filter(t => 
      format(new Date(t.trip_start_date), 'yyyy-MM-dd') === format(today, 'yyyy-MM-dd')
    );
    const yesterdayTrips = trips.filter(t => 
      format(new Date(t.trip_start_date), 'yyyy-MM-dd') === format(yesterday, 'yyyy-MM-dd')
    );
    
    if (todayTrips.length > 0 && yesterdayTrips.length > 0) {
      const todayRevenue = todayTrips.reduce((sum, t) => sum + (t.net_profit || 0), 0);
      const yesterdayRevenue = yesterdayTrips.reduce((sum, t) => sum + (t.net_profit || 0), 0);
      
      if (todayRevenue > yesterdayRevenue * 1.2) {
        const revenueIncrease = ((todayRevenue - yesterdayRevenue) / yesterdayRevenue) * 100;
        detectedAnomalies.push({
          id: 'revenue-increase',
          type: 'success',
          category: 'trip',
          title: 'Excellent Performance Today!',
          description: `Revenue up ${revenueIncrease.toFixed(1)}% compared to yesterday`,
          metric: {
            current: `₹${todayRevenue.toLocaleString('en-IN')}`,
            previous: `₹${yesterdayRevenue.toLocaleString('en-IN')}`,
            change: revenueIncrease,
            unit: ''
          },
          timestamp: new Date(),
          icon: <Zap className="h-4 w-4" />
        });
      }
    }
    
    // Sort by severity: critical > warning > info > success
    const severityOrder = { critical: 0, warning: 1, info: 2, success: 3 };
    return detectedAnomalies.sort((a, b) => 
      severityOrder[a.type] - severityOrder[b.type]
    );
  }, [trips, vehicles, drivers, documents, maintenance, expenses]);
  
  const typeColors = {
    critical: 'bg-red-50 dark:bg-red-900/30 border-red-300 dark:border-red-700',
    warning: 'bg-yellow-50 dark:bg-yellow-900/30 border-yellow-300 dark:border-yellow-700',
    info: 'bg-blue-50 dark:bg-blue-900/30 border-blue-300 dark:border-blue-700',
    success: 'bg-green-50 dark:bg-green-900/30 border-green-300 dark:border-green-700'
  };
  
  const typeIconColors = {
    critical: 'text-red-600 dark:text-red-400',
    warning: 'text-yellow-600 dark:text-yellow-400',
    info: 'text-blue-600 dark:text-blue-400',
    success: 'text-green-600 dark:text-green-400'
  };
  
  if (anomalies.length === 0) {
    return (
      <div className="bg-white dark:bg-gray-900 rounded-lg shadow-sm p-6">
        <h2 className="text-lg font-semibold text-gray-900 dark:text-gray-100 mb-4">
          Anomaly Detection
        </h2>
        <div className="text-center py-8">
          <CheckCircle className="h-12 w-12 text-green-500 mx-auto mb-3" />
          <p className="text-gray-600 dark:text-gray-400">
            All systems operating normally
          </p>
          <p className="text-sm text-gray-500 dark:text-gray-500 mt-1">
            No unusual patterns detected
          </p>
        </div>
      </div>
    );
  }
  
  return (
    <div className="bg-white dark:bg-gray-900 rounded-lg shadow-sm p-6">
      <div className="flex items-center justify-between mb-4">
        <div>
          <h2 className="text-lg font-semibold text-gray-900 dark:text-gray-100">
            Anomaly Detection
          </h2>
          <p className="text-sm text-gray-500 dark:text-gray-400">
            {anomalies.length} unusual patterns detected
          </p>
        </div>
        <div className="flex gap-2">
          <span className="px-2 py-1 text-xs font-medium text-red-700 dark:text-red-300 bg-red-100 dark:bg-red-900/30 rounded-full">
            {anomalies.filter(a => a.type === 'critical').length} Critical
          </span>
          <span className="px-2 py-1 text-xs font-medium text-yellow-700 dark:text-yellow-300 bg-yellow-100 dark:bg-yellow-900/30 rounded-full">
            {anomalies.filter(a => a.type === 'warning').length} Warning
          </span>
        </div>
      </div>
      
      <div className="space-y-3 max-h-96 overflow-y-auto">
        {anomalies.map((anomaly) => (
          <div
            key={anomaly.id}
            className={cn(
              "p-4 rounded-lg border transition-all hover:shadow-md",
              typeColors[anomaly.type]
            )}
          >
            <div className="flex items-start justify-between">
              <div className="flex items-start gap-3 flex-1">
                <div className={cn(
                  "p-2 rounded-lg",
                  typeIconColors[anomaly.type]
                )}>
                  {anomaly.icon}
                </div>
                <div className="flex-1">
                  <h3 className="font-medium text-gray-900 dark:text-gray-100 text-sm">
                    {anomaly.title}
                  </h3>
                  <p className="text-xs text-gray-600 dark:text-gray-400 mt-1">
                    {anomaly.description}
                  </p>
                  
                  {anomaly.metric && (
                    <div className="mt-2 flex items-center gap-4 text-xs">
                      <div>
                        <span className="text-gray-500 dark:text-gray-500">Current:</span>
                        <span className="ml-1 font-medium text-gray-900 dark:text-gray-100">
                          {anomaly.metric.current} {anomaly.metric.unit}
                        </span>
                      </div>
                      <div>
                        <span className="text-gray-500 dark:text-gray-500">Previous:</span>
                        <span className="ml-1 font-medium text-gray-600 dark:text-gray-400">
                          {anomaly.metric.previous} {anomaly.metric.unit}
                        </span>
                      </div>
                      {anomaly.metric.change !== 0 && (
                        <div className={cn(
                          "flex items-center gap-1",
                          anomaly.metric.change > 0 ? "text-green-600" : "text-red-600"
                        )}>
                          {anomaly.metric.change > 0 ? 
                            <TrendingUp className="h-3 w-3" /> : 
                            <TrendingDown className="h-3 w-3" />
                          }
                          <span className="font-medium">
                            {Math.abs(anomaly.metric.change).toFixed(1)}%
                          </span>
                        </div>
                      )}
                    </div>
                  )}
                </div>
              </div>
              
              {anomaly.action && (
                <button
                  onClick={anomaly.action.onClick}
                  className={cn(
                    "px-3 py-1.5 text-xs font-medium rounded-lg transition-colors flex items-center gap-1",
                    anomaly.type === 'critical' 
                      ? "text-white bg-red-600 hover:bg-red-700 dark:bg-red-700 dark:hover:bg-red-600"
                      : anomaly.type === 'warning'
                      ? "text-yellow-700 bg-yellow-200 hover:bg-yellow-300 dark:text-yellow-200 dark:bg-yellow-800 dark:hover:bg-yellow-700"
                      : "text-gray-700 bg-gray-200 hover:bg-gray-300 dark:text-gray-200 dark:bg-gray-700 dark:hover:bg-gray-600"
                  )}
                >
                  {anomaly.action.label}
                  <ChevronRight className="h-3 w-3" />
                </button>
              )}
            </div>
          </div>
        ))}
      </div>
      
      <div className="mt-4 pt-4 border-t border-gray-200 dark:border-gray-700 flex justify-between items-center">
        <button className="text-sm text-primary-600 dark:text-primary-400 hover:text-primary-700 dark:hover:text-primary-300 font-medium flex items-center gap-1">
          <Eye className="h-4 w-4" />
          View All Anomalies
        </button>
        <button className="text-sm text-gray-600 dark:text-gray-400 hover:text-gray-700 dark:hover:text-gray-300">
          Configure Alerts
        </button>
      </div>
    </div>
  );
}
