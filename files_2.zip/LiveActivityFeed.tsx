import React, { useEffect, useState, useMemo } from 'react';
import { 
  MapPin, Truck, DollarSign, Fuel, Users, Shield, 
  Wrench, Clock, CheckCircle, AlertCircle, TrendingUp,
  TrendingDown, Calendar, Package, Activity, MoreVertical,
  Bell, MessageSquare, Share2, Star
} from 'lucide-react';
import { format, formatDistanceToNow } from 'date-fns';
import { cn } from '@/lib/utils';

interface FeedEvent {
  id: string;
  type: 'trip' | 'maintenance' | 'document' | 'expense' | 'driver' | 'vehicle' | 'kpi';
  category: 'success' | 'warning' | 'info' | 'critical';
  title: string;
  description: string;
  timestamp: Date;
  actor?: {
    name: string;
    role: string;
    avatar?: string;
  };
  metrics?: {
    label: string;
    value: string | number;
    change?: number;
    unit?: string;
  }[];
  actions?: {
    label: string;
    icon?: React.ReactNode;
    onClick: () => void;
  }[];
  isNew?: boolean;
  isPinned?: boolean;
}

interface LiveActivityFeedProps {
  trips: any[];
  vehicles: any[];
  drivers: any[];
  maintenance: any[];
  documents: any[];
  expenses: any[];
  limit?: number;
  showFilters?: boolean;
}

export default function LiveActivityFeed({
  trips = [],
  vehicles = [],
  drivers = [],
  maintenance = [],
  documents = [],
  expenses = [],
  limit = 20,
  showFilters = true
}: LiveActivityFeedProps) {
  
  const [selectedFilter, setSelectedFilter] = useState<string>('all');
  const [autoRefresh, setAutoRefresh] = useState(true);
  const [lastUpdate, setLastUpdate] = useState(new Date());
  
  // Generate feed events from data
  const feedEvents = useMemo(() => {
    const events: FeedEvent[] = [];
    const now = new Date();
    
    // Recent trips
    const recentTrips = trips
      .filter(trip => {
        const tripDate = new Date(trip.trip_end_date || trip.trip_start_date);
        const hoursSince = (now.getTime() - tripDate.getTime()) / (1000 * 60 * 60);
        return hoursSince <= 48;
      })
      .slice(0, 5);
    
    recentTrips.forEach(trip => {
      const vehicle = vehicles.find(v => v.id === trip.vehicle_id);
      const driver = drivers.find(d => d.id === trip.driver_id);
      const profitMargin = trip.net_profit / (trip.total_cost || 1);
      
      events.push({
        id: `trip-${trip.id}`,
        type: 'trip',
        category: profitMargin > 0.2 ? 'success' : profitMargin > 0.1 ? 'info' : 'warning',
        title: `Trip Completed: ${trip.from_location} → ${trip.to_location}`,
        description: `${vehicle?.registration_number || 'Vehicle'} driven by ${driver?.name || 'Driver'}`,
        timestamp: new Date(trip.trip_end_date || trip.trip_start_date),
        actor: driver ? {
          name: driver.name,
          role: 'Driver',
          avatar: driver.avatar
        } : undefined,
        metrics: [
          {
            label: 'Distance',
            value: trip.end_km - trip.start_km,
            unit: 'km'
          },
          {
            label: 'Profit',
            value: `₹${trip.net_profit?.toLocaleString('en-IN') || 0}`,
            change: profitMargin * 100
          },
          {
            label: 'Mileage',
            value: trip.calculated_kmpl?.toFixed(1) || '-',
            unit: 'km/L'
          }
        ],
        actions: [
          {
            label: 'View Details',
            icon: <MapPin className="h-3 w-3" />,
            onClick: () => console.log('View trip', trip.id)
          }
        ],
        isNew: (now.getTime() - new Date(trip.trip_end_date || trip.trip_start_date).getTime()) < (1000 * 60 * 60 * 2)
      });
    });
    
    // Upcoming maintenance
    const upcomingMaintenance = maintenance
      .filter(m => {
        const scheduledDate = new Date(m.scheduled_date);
        const daysUntil = (scheduledDate.getTime() - now.getTime()) / (1000 * 60 * 60 * 24);
        return m.status === 'scheduled' && daysUntil <= 7 && daysUntil >= -1;
      })
      .slice(0, 3);
    
    upcomingMaintenance.forEach(task => {
      const vehicle = vehicles.find(v => v.id === task.vehicle_id);
      const daysUntil = Math.floor((new Date(task.scheduled_date).getTime() - now.getTime()) / (1000 * 60 * 60 * 24));
      
      events.push({
        id: `maintenance-${task.id}`,
        type: 'maintenance',
        category: daysUntil < 0 ? 'critical' : daysUntil <= 1 ? 'warning' : 'info',
        title: `Maintenance ${daysUntil < 0 ? 'Overdue' : 'Scheduled'}: ${task.maintenance_type}`,
        description: `${vehicle?.registration_number || 'Vehicle'} - ${task.description || 'Regular service'}`,
        timestamp: new Date(task.scheduled_date),
        metrics: task.estimated_cost ? [
          {
            label: 'Est. Cost',
            value: `₹${task.estimated_cost.toLocaleString('en-IN')}`
          }
        ] : undefined,
        actions: [
          {
            label: daysUntil < 0 ? 'Schedule Now' : 'View Details',
            icon: <Wrench className="h-3 w-3" />,
            onClick: () => console.log('View maintenance', task.id)
          }
        ],
        isPinned: daysUntil < 0
      });
    });
    
    // Document expiries
    const expiringDocs = documents
      .filter(doc => {
        const expiryDate = new Date(doc.expiry_date);
        const daysUntil = (expiryDate.getTime() - now.getTime()) / (1000 * 60 * 60 * 24);
        return daysUntil <= 14 && daysUntil >= -7;
      })
      .slice(0, 3);
    
    expiringDocs.forEach(doc => {
      const vehicle = vehicles.find(v => v.registration_number === doc.vehicle_registration);
      const daysUntil = Math.floor((new Date(doc.expiry_date).getTime() - now.getTime()) / (1000 * 60 * 60 * 24));
      
      events.push({
        id: `document-${doc.id}`,
        type: 'document',
        category: daysUntil < 0 ? 'critical' : daysUntil <= 3 ? 'warning' : 'info',
        title: `${doc.document_type} ${daysUntil < 0 ? 'Expired' : 'Expiring Soon'}`,
        description: vehicle?.registration_number || doc.vehicle_registration || 'Document',
        timestamp: new Date(doc.expiry_date),
        metrics: doc.renewal_cost ? [
          {
            label: 'Renewal Cost',
            value: `₹${doc.renewal_cost.toLocaleString('en-IN')}`
          }
        ] : undefined,
        actions: [
          {
            label: 'Renew Now',
            icon: <Shield className="h-3 w-3" />,
            onClick: () => console.log('Renew document', doc.id)
          }
        ],
        isPinned: daysUntil <= 3
      });
    });
    
    // Recent high expenses
    const recentHighExpenses = expenses
      .filter(expense => {
        const expenseDate = new Date(expense.expense_date);
        const daysSince = (now.getTime() - expenseDate.getTime()) / (1000 * 60 * 60 * 24);
        return daysSince <= 7 && expense.amount > 5000;
      })
      .slice(0, 2);
    
    recentHighExpenses.forEach(expense => {
      const vehicle = vehicles.find(v => v.id === expense.vehicle_id);
      
      events.push({
        id: `expense-${expense.id}`,
        type: 'expense',
        category: expense.amount > 10000 ? 'warning' : 'info',
        title: `High Expense: ${expense.category}`,
        description: `${vehicle?.registration_number || 'Fleet'} - ${expense.description}`,
        timestamp: new Date(expense.expense_date),
        metrics: [
          {
            label: 'Amount',
            value: `₹${expense.amount.toLocaleString('en-IN')}`
          }
        ],
        actions: [
          {
            label: 'View Receipt',
            icon: <DollarSign className="h-3 w-3" />,
            onClick: () => console.log('View expense', expense.id)
          }
        ]
      });
    });
    
    // KPI Milestones
    const totalTripsToday = trips.filter(t => {
      const tripDate = format(new Date(t.trip_start_date), 'yyyy-MM-dd');
      return tripDate === format(now, 'yyyy-MM-dd');
    }).length;
    
    if (totalTripsToday > 0 && totalTripsToday % 10 === 0) {
      events.push({
        id: `kpi-trips-${totalTripsToday}`,
        type: 'kpi',
        category: 'success',
        title: `Milestone: ${totalTripsToday} Trips Today! 🎉`,
        description: 'Fleet performance is excellent',
        timestamp: now,
        metrics: [
          {
            label: 'Trips',
            value: totalTripsToday,
            change: 25 // Example percentage increase
          }
        ],
        isPinned: true,
        isNew: true
      });
    }
    
    // Sort by timestamp (newest first) and pinned items
    return events.sort((a, b) => {
      if (a.isPinned && !b.isPinned) return -1;
      if (!a.isPinned && b.isPinned) return 1;
      return b.timestamp.getTime() - a.timestamp.getTime();
    });
  }, [trips, vehicles, drivers, maintenance, documents, expenses]);
  
  // Filter events based on selection
  const filteredEvents = useMemo(() => {
    if (selectedFilter === 'all') return feedEvents.slice(0, limit);
    return feedEvents.filter(event => event.type === selectedFilter).slice(0, limit);
  }, [feedEvents, selectedFilter, limit]);
  
  // Auto-refresh timer
  useEffect(() => {
    if (autoRefresh) {
      const interval = setInterval(() => {
        setLastUpdate(new Date());
      }, 30000); // Refresh every 30 seconds
      
      return () => clearInterval(interval);
    }
  }, [autoRefresh]);
  
  const getCategoryIcon = (type: string) => {
    switch (type) {
      case 'trip': return <Truck className="h-4 w-4" />;
      case 'maintenance': return <Wrench className="h-4 w-4" />;
      case 'document': return <Shield className="h-4 w-4" />;
      case 'expense': return <DollarSign className="h-4 w-4" />;
      case 'driver': return <Users className="h-4 w-4" />;
      case 'vehicle': return <Truck className="h-4 w-4" />;
      case 'kpi': return <TrendingUp className="h-4 w-4" />;
      default: return <Activity className="h-4 w-4" />;
    }
  };
  
  const getCategoryColor = (category: string) => {
    switch (category) {
      case 'success': return 'bg-green-100 dark:bg-green-900/30 text-green-700 dark:text-green-300 border-green-200 dark:border-green-800';
      case 'warning': return 'bg-yellow-100 dark:bg-yellow-900/30 text-yellow-700 dark:text-yellow-300 border-yellow-200 dark:border-yellow-800';
      case 'critical': return 'bg-red-100 dark:bg-red-900/30 text-red-700 dark:text-red-300 border-red-200 dark:border-red-800';
      default: return 'bg-blue-100 dark:bg-blue-900/30 text-blue-700 dark:text-blue-300 border-blue-200 dark:border-blue-800';
    }
  };
  
  const filterButtons = [
    { value: 'all', label: 'All', count: feedEvents.length },
    { value: 'trip', label: 'Trips', count: feedEvents.filter(e => e.type === 'trip').length },
    { value: 'maintenance', label: 'Maintenance', count: feedEvents.filter(e => e.type === 'maintenance').length },
    { value: 'document', label: 'Documents', count: feedEvents.filter(e => e.type === 'document').length },
    { value: 'expense', label: 'Expenses', count: feedEvents.filter(e => e.type === 'expense').length }
  ];
  
  return (
    <div className="bg-white dark:bg-gray-900 rounded-lg shadow-sm">
      {/* Header */}
      <div className="p-6 border-b border-gray-200 dark:border-gray-700">
        <div className="flex items-center justify-between mb-4">
          <div>
            <h2 className="text-lg font-semibold text-gray-900 dark:text-gray-100 flex items-center gap-2">
              <Activity className="h-5 w-5 text-primary-600" />
              Live Activity Feed
              {autoRefresh && (
                <span className="inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium bg-green-100 dark:bg-green-900/30 text-green-800 dark:text-green-300">
                  <span className="w-1.5 h-1.5 bg-green-500 rounded-full animate-pulse mr-1"></span>
                  Live
                </span>
              )}
            </h2>
            <p className="text-sm text-gray-500 dark:text-gray-400 mt-1">
              Last updated {formatDistanceToNow(lastUpdate, { addSuffix: true })}
            </p>
          </div>
          
          <div className="flex items-center gap-2">
            <button
              onClick={() => setAutoRefresh(!autoRefresh)}
              className={cn(
                "p-2 rounded-lg transition-colors",
                autoRefresh 
                  ? "bg-primary-100 dark:bg-primary-900/30 text-primary-600 dark:text-primary-400"
                  : "bg-gray-100 dark:bg-gray-800 text-gray-600 dark:text-gray-400"
              )}
            >
              <Bell className="h-4 w-4" />
            </button>
          </div>
        </div>
        
        {/* Filters */}
        {showFilters && (
          <div className="flex gap-2 overflow-x-auto pb-2">
            {filterButtons.map(filter => (
              <button
                key={filter.value}
                onClick={() => setSelectedFilter(filter.value)}
                className={cn(
                  "px-3 py-1.5 rounded-lg text-sm font-medium whitespace-nowrap transition-all",
                  selectedFilter === filter.value
                    ? "bg-primary-100 dark:bg-primary-900/30 text-primary-700 dark:text-primary-300 ring-2 ring-primary-500"
                    : "bg-gray-100 dark:bg-gray-800 text-gray-600 dark:text-gray-400 hover:bg-gray-200 dark:hover:bg-gray-700"
                )}
              >
                {filter.label}
                {filter.count > 0 && (
                  <span className="ml-2 px-1.5 py-0.5 bg-white dark:bg-gray-900 rounded-full text-xs">
                    {filter.count}
                  </span>
                )}
              </button>
            ))}
          </div>
        )}
      </div>
      
      {/* Feed Items */}
      <div className="divide-y divide-gray-200 dark:divide-gray-700 max-h-[600px] overflow-y-auto">
        {filteredEvents.length === 0 ? (
          <div className="p-8 text-center">
            <Activity className="h-12 w-12 text-gray-400 mx-auto mb-3" />
            <p className="text-gray-600 dark:text-gray-400">No recent activity</p>
            <p className="text-sm text-gray-500 dark:text-gray-500 mt-1">
              Activity will appear here as it happens
            </p>
          </div>
        ) : (
          filteredEvents.map((event) => (
            <div
              key={event.id}
              className={cn(
                "p-4 hover:bg-gray-50 dark:hover:bg-gray-800 transition-colors",
                event.isNew && "bg-primary-50/50 dark:bg-primary-900/10",
                event.isPinned && "border-l-4 border-primary-500"
              )}
            >
              <div className="flex gap-3">
                {/* Icon */}
                <div className={cn(
                  "p-2 rounded-lg flex-shrink-0",
                  getCategoryColor(event.category)
                )}>
                  {getCategoryIcon(event.type)}
                </div>
                
                {/* Content */}
                <div className="flex-1 min-w-0">
                  <div className="flex items-start justify-between">
                    <div className="flex-1">
                      <h3 className="font-medium text-gray-900 dark:text-gray-100 text-sm">
                        {event.title}
                        {event.isNew && (
                          <span className="ml-2 px-1.5 py-0.5 bg-primary-100 dark:bg-primary-900/30 text-primary-600 dark:text-primary-400 text-xs rounded-full">
                            New
                          </span>
                        )}
                      </h3>
                      <p className="text-xs text-gray-600 dark:text-gray-400 mt-0.5">
                        {event.description}
                      </p>
                      
                      {/* Metrics */}
                      {event.metrics && event.metrics.length > 0 && (
                        <div className="flex flex-wrap gap-3 mt-2">
                          {event.metrics.map((metric, idx) => (
                            <div key={idx} className="flex items-center gap-1 text-xs">
                              <span className="text-gray-500 dark:text-gray-500">{metric.label}:</span>
                              <span className="font-medium text-gray-900 dark:text-gray-100">
                                {metric.value}{metric.unit && ` ${metric.unit}`}
                              </span>
                              {metric.change !== undefined && (
                                <span className={cn(
                                  "flex items-center gap-0.5 ml-1",
                                  metric.change > 0 ? "text-green-600" : "text-red-600"
                                )}>
                                  {metric.change > 0 ? 
                                    <TrendingUp className="h-3 w-3" /> : 
                                    <TrendingDown className="h-3 w-3" />
                                  }
                                  {Math.abs(metric.change).toFixed(0)}%
                                </span>
                              )}
                            </div>
                          ))}
                        </div>
                      )}
                      
                      {/* Timestamp */}
                      <div className="flex items-center gap-2 mt-2 text-xs text-gray-500 dark:text-gray-500">
                        <Clock className="h-3 w-3" />
                        {formatDistanceToNow(event.timestamp, { addSuffix: true })}
                      </div>
                    </div>
                    
                    {/* Actions */}
                    <div className="flex items-center gap-1 ml-2">
                      {event.actions?.map((action, idx) => (
                        <button
                          key={idx}
                          onClick={action.onClick}
                          className="p-1.5 text-gray-500 dark:text-gray-400 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-lg transition-colors"
                          title={action.label}
                        >
                          {action.icon || <MoreVertical className="h-4 w-4" />}
                        </button>
                      ))}
                    </div>
                  </div>
                </div>
              </div>
            </div>
          ))
        )}
      </div>
      
      {/* Footer */}
      {filteredEvents.length > 0 && (
        <div className="p-4 border-t border-gray-200 dark:border-gray-700">
          <button className="w-full py-2 text-sm font-medium text-primary-600 dark:text-primary-400 hover:text-primary-700 dark:hover:text-primary-300 transition-colors">
            Load More Events
          </button>
        </div>
      )}
    </div>
  );
}
